// параметр  legs (наличие ног) внесла в отдельный класс, и сделала функцию check_lengs  
//дружественной только для этого класса, потэтому она не может получать другие парамтры элемента furniture

#include <iostream>
using namespace std;

int islegs = 1;

class limbs {
    public:
    limbs () : legs(0){};
    limbs (bool _legs) : legs(_legs){};
    ~limbs () {};
    bool get_legs () {
        return legs;
    }
    void set_legs(bool _legs) {
        legs = _legs;
    };
    friend void check_legs(limbs _legs, int islegs);
    private:
    bool legs;
};

class furniture {
    public:
    limbs leg;
    furniture(): name("furniture"), color("color"), height(0), length(0), width(0) {
        leg.set_legs(0);
        cout << "Empty furniture is constucted" << endl;
        cout << "Parametrs: " << endl << "name: " << name << endl << "color: "<< color << endl 
        << "size: "<< height << "x" << length << "x" << width << endl;
    }
    furniture (string _name, string _color, int _height, int _length,int _width){
        name = _name;
        color = _color;
        height = _height;
        length = _length;
        width = _width;
        cout << "furniture is constructed" << endl;
        cout << "Parametrs: " << endl << "name: " << name << endl << "color: "<< color << endl 
        << "size: "<< height << "x" << length << "x" << width << endl;
    }
    ~furniture () {
        cout << "Destructing " << name << endl;
    }
    int get_height () {
        return height;
    }
    void set_height (int _height) {
        height = _height;
    }
    string get_name () {
        return 0;
    }
    private:
    string name;
    string color;
    int height;
    int length;
    int width;
};

void check_legs(limbs _legs, int islegs);



int main () {
    furniture first;
    cout << first.get_name << ' ';
    check_legs(first.leg, islegs);
    cout << endl;
    furniture second ("table","black", 70, 70, 80);
    second.leg.set_legs(1);
    second.set_height(60);
    cout << second.get_name << ' ';
    check_legs(second.leg, islegs);
    cout << endl;
    return 0;
}

void check_legs(limbs _leg, int islegs) {
    if(islegs && _leg.legs) {
        cout << " has legs" << endl;
    } else {
        cout << " has not got legs" << endl; 
    }
}