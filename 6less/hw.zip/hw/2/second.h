#ifndef MYCLASS_H
#define MYCLASS_H

#include <iostream>
#include <utility>

using namespace std;
namespace rational {
class Rational {
public:
    Rational() ;
    Rational(int numerator, int denominator);
    Rational(int numerator);
    Rational(const Rational &rational); // конструктор копирования
    Rational& operator=(const Rational& rational); // оператор копирования присваиванием
    Rational(Rational&& rational); // Конструктор перемещения
    Rational modification (int numerator, int denominator);
    Rational & operator=(Rational&& rational); 
    int Numerator() const ;

    int Denominator() const;
    void set_numerator(int numerator);
    void set_denominator (int denominator);
    // не делаю дружественные функции так как есть Numerator и Denominator
    
private:
    int p;
    int q;
};
//}
rational::Rational operator / (const rational::Rational& lhs, const rational::Rational& rhs);
rational::Rational operator + (rational::Rational a, rational::Rational b);
rational::Rational operator - (rational::Rational a, rational::Rational b);
rational::Rational operator * (rational::Rational a, rational::Rational b);
istream& operator >> (istream& stream, rational::Rational& r);
 
ostream& operator << (ostream& stream, const rational::Rational& r);

bool operator > (rational::Rational a, rational::Rational b);

bool operator < (rational::Rational a, rational::Rational b);

void action (const rational::Rational &r1, const rational::Rational &r2, const char & c);
}
#endif //MYCLASS