#include "second.h"
using namespace std;

    rational::Rational::Rational() :p(0), q(1) {}
    rational::Rational::Rational(int numerator, int denominator) {
    	if (denominator == 0) {
    		cout << "Некорректные данные" << endl;
    	}
        // rational::Rational R;
        // R = rational::Rational::modification(numerator, denominator);
        // p = R.p;
        // q = R.q; почему-то underfined reference  в операторах работает
        int a = numerator, b = denominator, c = 0;
        while (b != 0) {
            c = a % b;
            a = b;
            b = c;
        }
        if (denominator / a < 0) {
            denominator = -denominator;
            numerator = -numerator;
        }
        p = numerator / a;
        q = denominator / a;
        
    }
    rational::Rational::Rational(int numerator) : p(numerator), q(1){};
    rational::Rational::Rational(const Rational &rational) = default;
    rational::Rational& rational::Rational::operator=(const Rational& rational) = default;
    //  {
    //     if (&rational ==this) {
    //         return *this;
    //     }
    //     p = rational.p;
    //     q = rational.q;
    //     return *this;
    // } // оператор копирования присваиванием
    rational::Rational::Rational(Rational&& rational) = default;
    rational::Rational & rational::Rational::operator=(Rational&& rational)=default; //{
    //     if(&rational == this) {
    //         return *this;
    //     }

    //     p = move(rational.p);
    //     q = move(rational.q);
    //     return *this;
    //     } 
    rational::Rational modification (int numerator, int denominator) {
        int a = numerator, b = denominator, c = 0;
        while (b != 0) {
            c = a % b;
            a = b;
            b = c;
        }
        if (denominator / a < 0) {
            denominator = -denominator;
            numerator = -numerator;
        }
        rational::Rational R;
        R.set_numerator(numerator / a);
        R.set_denominator(denominator / a);
        return R;
    }
    int rational::Rational::Numerator() const {
        return p;
    }

    int rational::Rational::Denominator() const {
        return q;
    }
    void rational::Rational::set_numerator(int numerator){
        p = numerator;
    }
    void rational::Rational::set_denominator (int denominator){
        q = denominator;
    }
    // не делаю дружественные функции так как есть Numerator и Denominator

rational::Rational operator / (const rational::Rational& lhs, const rational::Rational& rhs) {
    if (rhs.Numerator() == 0) {
        throw domain_error("Division by zero");
    }
    return modification(lhs.Numerator() * rhs.Denominator(),lhs.Denominator() * rhs.Numerator());
}
rational::Rational operator + (rational::Rational a, rational::Rational b) { 
    return modification(a.Numerator() * b.Denominator() + b.Numerator() * a.Denominator(),a.Denominator() * b.Denominator());
}
rational::Rational operator - (rational::Rational a, rational::Rational b) {
    return modification(a.Numerator() * b.Denominator() - b.Numerator() * a.Denominator(),a.Denominator() * b.Denominator());
}
rational::Rational operator * (rational::Rational a, rational::Rational b) {
    return modification(a.Numerator()*b.Numerator(),a.Denominator() * b.Denominator());
}
istream& operator >> (istream& stream, rational::Rational& r) {
    int p, q;
    if (stream >> p && stream.ignore(1) && stream >> q) {
        r = { p, q };
    }
    return stream;
}
 
ostream& operator << (ostream& stream, const rational::Rational& r) {
    stream << r.Numerator() << "/" << r.Denominator();
    return stream;
}

bool operator > (rational::Rational a, rational::Rational b) {
    return (a.Numerator() * b.Denominator()) > (b.Numerator() * a.Denominator());
}
bool operator < (rational::Rational a, rational::Rational b) {
    return (a.Numerator() * b.Denominator()) < (b.Numerator() * a.Denominator());
}

void action (const rational::Rational &r1, const rational::Rational &r2, const char & c) {
    cout <<"result: ";
    if ( c == '+') {
        cout << r1+r2 << endl;
    } else if ( c == '-') {
        cout << r1-r2 << endl;
    } else if (c == '*') {
        cout << r1*r2 << endl;
    } else if (c =='/'){
        cout << r1/r2 << endl;
    } else {
        cout << "Wrong operation" << endl;
    }
};
