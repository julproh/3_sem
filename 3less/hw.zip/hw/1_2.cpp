#include <iostream>

using namespace std;

void function(char c = 'c') {
    cout << c << endl;
}

void function (int i = 1) {
    cout << i << endl;
}

int main () {
    function();
    return 0;
}