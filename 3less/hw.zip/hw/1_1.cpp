#include <iostream>

using namespace std;

void function(float i) {
    cout << i << endl;
}

void function(double i) {
    cout << i << endl;
}

int main () {
    function(10.0);
    function(10); // ошибка 
    return 0;
}
