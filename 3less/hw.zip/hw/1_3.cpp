#include <iostream>
using namespace std;

char myfunc (unsigned char ch) {
    return ch;
}

char myfunc(char ch){
    return ch;
}


int main()
{
    cout << myfunc('p') << endl; 
    return 0;
}
